# Memory: index.md
Updated: now

# Project Memory

## Core
- Stack: Supabase (Auth, RLS, Edge Functions, pg_cron), React Query (no legacy useEffect for data). Recharts for charts.
- Theme: Dark for Admins/Influencers (emerald/navy accents). Light for Users (white/blue #448AFF).
- Roles: Super Admin, Manager, Influencer, User. Main portal is login-only; no self-registration for admins.
- Auth: Google OAuth (id_token only) & 6-digit OTP via SendGrid (`support@constil.com`).
- Admin Identity: Never delete Super Admin `miqdadr9@gmail.com` (UUID: 10eca3f1-308f-4d05-99da-b16704c15f61).
- Payments: Stripe API (Checkout & Webhooks). All math is server-side. Mock endpoints are deprecated.
- External business portal (clients/products/invoices/estimates/taxes/discounts/company_profiles/ai_*) uses **direct Supabase REST** with RLS — NOT custom edge functions. API_DOCUMENTATION.md v11.0 is the source of truth.

## Memories
- [Overview](mem://project/overview) — Paybue SaaS summary, 4-role affiliate marketing ecosystem
- [Commission & Attribution](mem://business-logic/commission-and-attribution) — First-click prioritization, manual coupon checkout, percentage splits
- [Visual Direction](mem://style/visual-direction) — Dual-theme aesthetic details, colors, and logo branding
- [Credit System](mem://business-logic/credit-system) — Segmented buckets (invoice, estimate, AI), unlimited toggles, legacy fallback
- [Automation](mem://tech-stack/automation) — Nightly commission and hourly trial expiration via pg_cron
- [Payout Workflow](mem://business-logic/payout-workflow) — Super Admin manual review, Stripe Connect Express vs manual bank transfer
- [Coupon Management](mem://features/coupon-management) — Auto-generation logic, ownership vs supervision rules
- [Subscriptions & Access](mem://business-logic/subscriptions-and-access) — Tiered plans, subscription stacking, template library gating
- [Payment Integration](mem://tech-stack/payment-integration) — Server-side Stripe checkout logic, webhook reliance
- [Email Template Access](mem://features/email-template-access) — Basic/Pro/Enterprise template gating rules
- [Auth Flow](mem://features/auth-flow) — 6-digit OTP, sendgrid config, account enumeration prevention
- [Trial Subscriptions](mem://features/trial-subscriptions) — Payment-upfront trials, restricted credits, auto-conversion via webhook
- [Subscription Dashboard](mem://features/user-subscription-dashboard) — 'My Subscription' UI, real-time usage bars, conditional upgrade banners
- [Admin Tools](mem://features/admin-tools-and-hierarchy) — Dashboard separation for roles, credit history audit trail
- [External Integration](mem://tech-stack/external-integration) — REST API (v11.0+) user lifecycle + business management resources
- [Security Architecture](mem://tech-stack/security-architecture) — Session management, input sanitization, strict rate limits
- [Support Ticketing](mem://features/support-ticketing) — Public form, edge function processing, dashboard status tracking
- [Business Portal](mem://features/business-management-portal) — Light-themed legacy migration for clients/products/invoices CRUD
- [Documentation](mem://project/documentation) — Paybue_System_Guide.pdf and API reference v11.0 details
- [Integration Strategy](mem://project/integration-strategy) — constilPortal merger, native auth replacement
- [Google OAuth Config](mem://tech-stack/google-oauth-config) — Client ID and domain whitelisting requirements
